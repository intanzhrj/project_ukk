<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GalleryController;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Like;
use App\Models\Komentar;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/navbar1', function () {
    return view('navbar1');
});

Route::get('/navbar', function () {
    return view('navbar');
});

// Route::get('/login', function () {
//     return view('login');
// });

Route::get('/home', function () {
    return view('home');
});

Route::get('/beranda', function () {
    $bebas = Foto::all();
    return view('beranda', compact('bebas'));
});

Route::get('/kategori', function () {
    return view('kategori');
});

Route::get('/album', function () {
    return view('album');
});

Route::get('/pict', function () {
    return view('pict');
});


Route::get('/deskripsi', function () {
    return view('deskripsi');
});

Route::get('/deskripsi/{FotoID}', function($FotoID){
    $foto = Foto::where('FotoID', $FotoID)->first();
    $like = Like::where('FotoID', $FotoID)->get();
    $komen= Komentar::where('FotoID', $FotoID)->get();
    $user2 = User::all();
    return view('deskripsi', compact('foto','like','komen','user2'));
});

// Route::get('/register', function () {
//     return view('register');
// });

Route::get('/register', [GalleryController::class,'panggilview']);
Route::post('/login', [GalleryController::class,'aksiregister']);

Route::get('/login', [GalleryController::class,'panggil']);
Route::post('/log', [GalleryController::class,'aksilogin']);

Route::get('/pict', [GalleryController::class,'view']);
Route::post('/beranda', [GalleryController::class,'aksifoto']);

Route::post('/album', [GalleryController::class,'aksialbum']);
Route::get('/kategori', [GalleryController::class,'tampilAlbum']);

Route::get('/album{FotoID}', [GalleryController::class,'datafoto']);

Route::get('/deskripsi/{FotoID}', function($FotoID){
    $foto = Foto::where('FotoID', $FotoID)->first();
    $like = Like::where('FotoID', $FotoID)->get();
    $komen= Komentar::where('FotoID', $FotoID)->get();
    $user2 = User::all();
    return view('deskripsi', compact('foto','like','komen','user2'));
});
// untuk memberi like
Route::get('/berilike/{FotoID}', [GalleryController::class, 'like']);
// untuk memberi komen
Route::post('/berikomen/{FotoID}', [GalleryController::class,'komen']);
// untuk menghapus album
Route::get('/hapusdata/{AlbumID}', [GalleryController::class, 'hapusdata']);
// ini untuk menghapus foto
Route::get('/hapusfoto/{FotoID}', [GalleryController::class, 'hapusfoto']);