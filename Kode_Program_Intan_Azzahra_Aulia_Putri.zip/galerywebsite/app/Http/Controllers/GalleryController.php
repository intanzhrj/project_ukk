<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Like;
use App\Models\Komentar;

class GalleryController extends Controller
{
    public function panggilview(){
        return view ('register');
    }

    // ini aksi register 
    public function aksiregister (Request $request){
        $data = new User();
    $data->username =$request->input('username'); 
    $data->password =$request->input('password');
    $data->email =$request->input('email');
    $data->namalengkap =$request->input('fullname');
    $data->alamat =$request->input('alamat');
    $data->save(); 

    return redirect('/login');
    }

    // ini aksi login
    public function panggil(){
        return view ('login');
    }
    public function aksilogin(Request $request){

        $data = User::where('username', $request->input('username'))->where('password', $request->input('password'))->first();

        if($data !=null){
            session()->put('user', $data);
            return redirect('/beranda');
        }else{
            return redirect()->back()->with('pesan', 'Username/Password Salah!!');
        }

    }

    public function tampilAlbum() {
        $bebas = Album::where('UserID', session('user')->UserID)->get();

        return view('kategori', compact('bebas'));
    }
    // ini aksi album
    public function aksialbum (Request $request){

        $data = new Album();
        $data->NamaAlbum =$request->input('namaalbum'); 
        $data->Deskripsi =$request->input('deskripsi');
        $data->TanggalDibuat = date('Y-m-d');
        $data->UserID = session('user')->UserID;
         $data->save();
        // dd($data);
        
         return redirect('/kategori');
        }
        // ini aksi tambah foto
        public function view(){
            $bebas = Album::where('UserID', session('user')->UserID)->get();
            
            return view('pict', compact('bebas'));
        }
        // 
            public function aksifoto(Request $request){
                if ($request->hasFile('foto')) {
        
                    $locate = $request->file('foto')->store('public/penyimpanan');
        
                    $data = new Foto();
                    $data->JudulFoto = $request->input('judulfoto');
                    $data->DeskripsiFoto = $request->input('deskripsi');
                    $data->TanggalUnggah = date ('Y-m-d');
                    $data->LokasiFile = $locate;
                    $data->AlbumID = $request->get('album');
                    $data->UserID = session('user')->UserID;
                    // dd($data);
                    $data->save();
                    return redirect('/beranda');
                }
                else{
                    echo "HAHAHAH";
                }
            }
            // ini aksi datafoto
            public function datafoto ($AlbumID)
            {
                $bebas = Album::find($AlbumID);
                $bebas = Foto::where('AlbumID', $AlbumID)->get();
                return view('datafoto', compact('bebas', 'bebas'));
            }
            // aksi like
            public function like($FotoID){
                $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
            
                if(!$cek){
                    $data = new Like();
                    $data->FotoID = $FotoID;
                    $data->UserID = session('user')->UserID;
                    $data->TanggalLike = now();
                    $data->save();
            
                    return redirect()->back();
                } else {
                    $cek->delete();
                    return redirect()->back();
                }
            }
            // aksi komen
            public function komen(Request $request,$FotoID){

                $data = new Komentar;
                $data ->FotoID = $FotoID;
                $data ->UserID = session('user')->UserID;
                $data ->IsiKomentar = $request->input('isi');
                $data ->TanggalKomentar= date ('Y-m-d H:i:s');
    
                $data -> save();
    
                return redirect()->back();
            }
            // ini untuk hapus album
            public function hapusdata($AlbumID)
            {
                $bebas = Album::find($AlbumID);
                $bebas->delete();
       
               return redirect('/kategori')->with('pesan', 'Album berhasil dihapus!');
           }
        //    ini untuk hapus foto
        public function hapusfoto($FotoID)
    {
        $bebas = Foto::find($FotoID);
        $bebas->delete();

       return redirect('/beranda')->with('pesan', 'Foto berhasil dihapus!');
   }
}