<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gallery's</title> 
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

  <style>

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
  }

  body{
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    /* background-color: #E1F0DA; */
    /* background-image: url('foto/79.jpg'); */

  }

  header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #99BC85;
  }

  .navigation a {    
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 20px;
  }

  .b a {
    position: relative;
    color: black;
    text-decoration: none;
    font-weight: 600;
  }

  .box {
    max-width: 400px;
    width: 100%;
  }

  .box .search-box {
    position: relative;
    height: 50px;
    max-width: 50px;
    margin: auto;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.25);
    border-radius: 25px;
    transition: all 0.3s ease;
  }

  #check:checked ~ .search-box {
    max-width: 380px;
  }

  .search-box input {
    position: absolute;
    height: 100%;
    width: 100%;
    border-radius: 25px;
    background: #fff;
    outline: none;
    border: none;
    padding-left: 20px;
    font-size: 18px;
  }

  .search-box .icon {
    position: absolute;
    right: -2px;
    top: 0;
    width: 50px;
    background: #fff;
    height: 100%;
    text-align: center;
    line-height: 50px;
    color: #294B29;
    font-size: 20px;
    border-radius: 25px;
  }

  #check:checked ~ .search-box .icon {
    background: #294B29;
    color: #FFF;
    width: 60px;
    border-radius: 0 25px 25px 0;
  }

  #check {
    display: none;
  }

  </style>

</head>

<body>
 
  <header>
    <nav class="b">
      <a href="#">Website Gallery</a>
    </nav>

    <div class="box">
      <input type="checkbox" id="check">
      <!-- <label for="check"></label> -->
    </div>

    <nav class="navigation">
      <a href="/register">Register</a> 
      <a href="/login">Login</a>    
    </nav>
  </header>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>

</html>
