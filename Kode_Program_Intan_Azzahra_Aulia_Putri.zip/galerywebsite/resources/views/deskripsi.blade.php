<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    /* ini css navbar */
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
  }
  
  body{
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: #E1F0DA !important;

  }

  header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #99BC85;
  }

  .navigation a {    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 20px;
  }

 

  .b a {
    position: relative;
 
    color: black;
    text-decoration: none;
    font-weight: 600;
   
  }

   .box{
  max-width: 400px;
  width: 100%;

}

.box .search-box{
  position: relative;
  height: 50px;
  max-width: 50px;
  margin: auto;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.25);
  border-radius: 25px;
  transition: all 0.3s ease;
}
  #check:checked ~ .search-box{
  max-width: 380px;
}
 .search-box input{
 position: absolute;
 height: 100%;
 width: 100%;
 border-radius: 25px;
 background: #fff;
 outline: none;
 border: none;
 padding-left: 20px;
 font-size: 18px;
}
.search-box .icon{
  position: absolute;
  right: -2px;
  top: 0;
  width: 50px;
  background: #fff;
  height: 100%;
  text-align: center;
  line-height: 50px;
  color: #294B29;
  font-size: 20px;
  border-radius: 25px;
}
 #check:checked ~ .search-box .icon{
  background: #294B29;
  color: #FFF;
  width: 60px;
  border-radius: 0 25px 25px 0;
}
 #check{
  display: none;
} */

    /* ini css table komen dan like */
    .see-img{
    margin-top: 10%;
    width: 45%;
    background-color: white;
    border-radius: 10px;
    position: relative;
    transform: translateX(-50%);
    left: 50%;
    box-shadow: 0 0 8px #222;
    overflow: hidden;
}
.see-img .fotonya img{
    width: 100%;
    border-radius: 10px;
    box-shadow: 0 0 5px #222;
}
.see-img .like-com{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    font-family: 'Nunito sans';
    font-weight: bold;
    padding: 2px 9px;
}
.see-img .like-com .btnlk{
    display: flex;
    flex-direction: row;
    font-size: 18px;
    align-items: center;
}
.see-img .like-com .btnlk .like{
    margin-right: 10px;
}
.see-img .like-com .btnlk .like a{
    color: #222;
    text-decoration: none;
}
.see-img .desk-img{
    padding: 2px 9px;
    font-family: 'Nunito sans';
    font-weight: bold;
}
.see-img .kom{
    padding: 2px 9px;
    font-family: 'Nunito sans';
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    margin: 30px 0px;
}
.see-img .create-kom{
    width: 100%;
    padding: 2px 9px;
}
.see-img .create-kom form{
    display: flex;
    flex-direction: row;
    /* justify-content: space-between; */
    width: 100%;
}
.see-img .create-kom .isi-komen{
    width: 90%;
    height: 25px;
    margin: 10px 0px 2px 0px;
    border-radius: 10px;
    border: 1px solid #222;
    padding: 3px 7px;
    font-family: 'Nunito sans';
}
.see-img .create-kom button{
    background-color: none;
    border: transparent;
    cursor: pointer;
}
.see-img .create-kom button i{
    font-size:20px;
    margin-left: 5px;
}
</style>
<body>

<header>
      <nav class="b">
        <a href="#">Website Gallery</a>
        {{ session('user')->Username}}  
      </nav>
    <div class="box">
    <input type="checkbox" id="check">
      </label>
    </div>
  </div>  
      <nav class="navigation">
        <a href="/beranda">beranda</a>   
      </nav>
  </header>

 <header>   
<nav class="b">
        <a href="#">Website Gallery</a>
        {{ session('user')->Username}}  
      </nav>
    <div class="box">
    <input type="checkbox" id="check">
      </label>
    </div>
  </div>  
      <nav class="navigation">
        <a href="/beranda">beranda</a>   
        <a href="/kategori">my album</a>    
      </nav>
  </header>


    <div class="see-img">
        <div class="fotonya">
            <img src="{{ Storage::url($foto->LokasiFile) }}" alt="...">
        </div>
        <div class="desk-img">
            <table>
                <tr>
                @if($nama = $user2->where('UserID', $foto->UserID)->first()){{$nama->Username}}
                @endif
                    <td>Judul Foto</td>
                    <td>:</td>
                    <td> {{ $foto->JudulFoto }}</td>
                </tr>
                <tr>
                    <td>Deskripsi Foto</td>
                    <td>:</td>
                    <td>{{ $foto->DeskripsiFoto }}</td>
                </tr>
            </table>
        </div>
        <div class="like-com">
            
            <div class="btnlk">
                <div class="like">

                    @if ($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first())
                        <a href="/berilike/{{ $foto->FotoID }}">
                            <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        {{ $like->where('FotoID', $foto->FotoID)->count() }}
                    @else
                        <a href="/berilike/{{ $foto->FotoID }}">
                            <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        {{ $like->where('FotoID', $foto->FotoID)->count() }}
                    @endif  
                </div>
                <div class="komentar">
                    <i class="fa-regular fa-comment" style="font-size: 20px"></i>
                    {{ $komen->count() }}
                </div>
            </div>
        </div>
        <hr style="width: 100%; color: black; height: 1px;background-color: black;">
        @if ($komen == null)
            <div class="kom">
                Belum ada komentar, jadilah pertama yang menanggapi!
            </div>
        @else
            @foreach ($komen as $kom)
                <div class="kom">
                    <div class="kom-left">
                        <div class="user-com"><i class="fa-solid fa-circle-user"></i>
                            @if ($namanya = $user2->where('UserID', $kom->UserID)->first())
                                {{ $namanya->NamaLengkap }}
                            @endif
                        </div>
                        <div class="isi-com">{{ $kom->IsiKomentar }}</div>
                    </div>
                    <div class="tgl-kom">
                        {{ $kom->TanggalKomentar }}
                    </div>
                </div>
            @endforeach
        @endif
        <div class="create-kom">
            <form action="/berikomen/{{$foto->FotoID}}" method="post">
                @csrf
                <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required class="isi-komen">
                <button><i class="fa-solid fa-paper-plane"></i></button>
            </form>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/29c53c391a.js" .crossorigin="anonymous"></script>
</body>
</html>