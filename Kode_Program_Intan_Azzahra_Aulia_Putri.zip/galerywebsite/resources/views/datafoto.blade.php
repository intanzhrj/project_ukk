<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>desk</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900');

        /* ini css navbar */
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
  }

  body{
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;

  }

  header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #99BC85;
  }

  .navigation a {    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 20px;
  }

 

  .b a {
    position: relative;
 
    color: black;
    text-decoration: none;
    font-weight: 600;
   
  }
   .box{
  max-width: 400px;
  width: 100%;

}

.box .search-box{
  position: relative;
  height: 50px;
  max-width: 50px;
  margin: auto;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.25);
  border-radius: 25px;
  transition: all 0.3s ease;
}
  #check:checked ~ .search-box{
  max-width: 380px;
}
 .search-box input{
 position: absolute;
 height: 100%;
 width: 100%;
 border-radius: 25px;
 background: #fff;
 outline: none;
 border: none;
 padding-left: 20px;
 font-size: 18px;
}
.search-box .icon{
  position: absolute;
  right: -2px;
  top: 0;
  width: 50px;
  background: #fff;
  height: 100%;
  text-align: center;
  line-height: 50px;
  color: #294B29;
  font-size: 20px;
  border-radius: 25px;
}
 #check:checked ~ .search-box .icon{
  background: #294B29;
  color: #FFF;
  width: 60px;
  border-radius: 0 25px 25px 0;
}
 #check{
  display: none;
} */


        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body
        {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #E1F0DA !important;

        }
        .container
        {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 100px 50px;
            padding: 100px 50px;
        }
        .container .card
        {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            width: 350px;
            height: 300px;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 35px 80px rgba(0,0,0,15);
            transition: 0,5s;
        }
        .container .card:hover
        {
            height: 400px;
        }
        .container .card .imgBx
        {
            position: absolute;
            top: 20px;
            width: 300px;
            height: 220px;
            background: #333;
            border-radius: 12px;
            overflow: hidden;
            transition: 0.5s;
        }
        .container .card:hover .imgBx
        {
            top: -100px;
            scale: 0.75;
            box-shadow: 0 15px 45px rgba(0,0,0,0,.15);
        }
        .container .card .imgBx img
        {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .container .card .content
        {
            position: absolute;
            top: 200px;
            width: 100%;
            padding: 0 30px;
            height: 35px;
            overflow: hidden;
            text-align: center;
            transition: 0.5px;
        }
        .container .card:hover .content
        {
            top: 130px;
            height: 250px;
        }
        .container .card .content h2
        {
            font-size: 1.5em;
            font-weight: 700;
            color: #436850;
        }
        .container .card .content p
        {
            color: #333;
        }
        .container .card .content a
        {
            position: relative;
            top: 15px;
            display: inline-block;
            padding: 12px 25px;
            background: #436850;
            color: #fff;
            font-weight: 500;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<header>
      <nav class="b">
        <a href="#">Website Gallery</a>
        {{ session('user')->Username}}  
      </nav>
    <div class="box">
    <input type="checkbox" id="check">
      </label>
    </div>
  </div>  
      <nav class="navigation">
        <a href="/beranda">beranda</a>   
        <a href="/kategori">album</a>  
      </nav>
  </header>
    <div class="container">
    @foreach ($bebas as $foto)
        <div class="card" style="--clr: #9F70FD;">
            <div  class="imgBx">
            <a href="/deskripsi/{{$foto->FotoID}}"><img src="{{ Storage::url($foto->LokasiFile)}}" alt=""></a>
            </div>
            <div class="content">
                <h2>Judul Foto: {{$foto->JudulFoto}}</h2>
                <p>Deskripsi Foto: {{$foto->DeskripsiFoto}}</p>
                <nav class="navigation">
                  <a href="/deskripsi/{{$foto->FotoID}}">lihat foto</a>    
                 </nav>
                 <!-- diatas itu codingan lihat foto dari album -->
                <!-- <a href="#">read more</a> -->
                
            </div>
        </div>
        <a href="/hapusfoto/{{ $foto->FotoID }}"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16" style="vertical-align: middle; margin-top: -16px; color: red;">
  <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
</svg></a>
      @endforeach
    </div>
</body>
</html>
