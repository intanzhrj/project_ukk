<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Card</title>
    <link rel="stylesheet" href="style.css" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  
  
    <style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #E1F0DA;
}

header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background: #99BC85;
  }

  .navigation a {    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 20px;
  }

 

  .b a {
    position: relative;
 
    color: black;
    text-decoration: none;
    font-weight: 600;
   
  }


 

   .box{
  max-width: 400px;
  width: 100%;

}

.box .search-box{
  position: relative;
  height: 50px;
  max-width: 50px;
  margin: auto;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.25);
  border-radius: 25px;
  transition: all 0.3s ease;
}
  #check:checked ~ .search-box{
  max-width: 380px;
}
 .search-box input{
 position: absolute;
 height: 100%;
 width: 100%;
 border-radius: 25px;
 background: #fff;
 outline: none;
 border: none;
 padding-left: 20px;
 font-size: 18px;
}
.search-box .icon{
  position: absolute;
  right: -2px;
  top: 0;
  width: 50px;
  background: #fff;
  height: 100%;
  text-align: center;
  line-height: 50px;
  color: #AE9371;
  font-size: 20px;
  border-radius: 25px;
}
 #check:checked ~ .search-box .icon{
  background: #AE9371;
  color: #FFF;
  width: 60px;
  border-radius: 0 25px 25px 0;
}
 #check{
  display: none;
}
::-webkit-scrollbar {
  height: 8px;
}
::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 25px;
}
::-webkit-scrollbar-thumb {
  background: #AE9371;
  border-radius: 25px;
}
::-webkit-scrollbar-thumb:hover {
  background: #C7B7A3;
}
/* .container {
  display: flex;
  gap: 12px;
  max-width: 400px;
  width: 100%;
  background: #E8D8C4;
  border-radius: 12px;
  padding: 30px;
  scroll-snap-type: x mandatory;
  overflow-x: scroll;
  scroll-padding: 30px;
  box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1);
} */
.container .card {
  display: flex;
  flex: 0 0 100%;
  flex-direction: column;
  align-items: center;
  padding: 30px;
  border-radius: 12px;
  background: #AE9371;
  scroll-snap-align: start;
  box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1);
}
.card .image {
  height: 150px;
  width: 150px;
  padding: 4px;
  background: ##AE9371;
  border-radius: 50%;
}
.image img {
  height: 100%;
  width: 100%;
  object-fit: cover;
  border-radius: 50%;
  border: 5px solid #fff;
}
.card h2 {
  margin-top: 25px;
  color: #333;
  font-size: 22px;
  font-weight: 600;
}
.card p {
  margin-top: 4px;
  font-size: 18px;
  font-weight: 400;
  color: #fff;
  text-align: center;
}

.text{
  font-family: "Poppins", sans-serif;
  color: black;
  font-size: 15px;
}
body{
            background-image: url('img/bbb.jpg');
            background-size: cover;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: <weight>;
            font-style: normal;
        }
        .back{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            left: 8%;
        }
        .grid{
             display: grid;
             grid-template-columns: repeat(4, 1fr);
             margin: 0px;
             align-items: center;
             grid-gap: 30px;
        }
        img{
            object-fit: cover;
        }
        .grid > article{
            box-shadow: 10px 5px 5px 0px black;
            border-radius: 20px;
            text-align: center;
            background: #99BC85;
            width: 250px;
            transition: transform;
            margin-top: 60px;
        }
        .grid  article img{
            border-top-left-radius: 30px;
            border-top-right-radius: 30px; width: 100%;
        }
       
        .grid > article:hover{
            transform: scale(1.2);
        }
        @media (max-width:1000px){
            .grid{
                grid-template-columns: repeat(2,1fr);
            }
        }
        @media (max-width:1000px){
            .grid{
                grid-template-columns: repeat(1,1fr);
            }
        }
        .garisatas{
            background-color: #BC8741;
            height: 3px;
            margin: 3% 6% 6% 6%;
            margin-bottom: -50px;  
        }
        .keluar{
            position: absolute;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 5%;
        }
        .keluar  a{
            color: #BC8741;
            text-decoration: none;   
        }
        .back h1 a{
            color: #BC8741;
            text-decoration: none;
        }
        .masuk{
            position: absolute;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 12%;
        }
        .masuk  a{
            color: #BC8741;
            text-decoration: none;
        }
        /* .come{
            position: absolute;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 22%;
        }
        .come {
            color: #BC8741;
            text-decoration: none;
        } */
        .container {
            display: flex;
            justify-content: center;
            align-items: center;   
        }
        
        
    </style>
  </head>
  <body style="background-image: url(foto/poi.jpg);">
  <header>
 <div class=" d-flex gap-3  ">
   <span class="badge d-flex p-2 align-items-center  ">
    <a href="/beranda"><span class="text">beranda</span></a> 
     <!-- <a href="/beranda" class="text-primary-emphasis">
      <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
   <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
 </svg>
</a> -->
   </span>
   <span class="badge d-flex p-2 align-items-center ">
     <span class="text">tambah foto</span>
     <a href="/pict" class="text-primary-emphasis"><svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
   <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
 </svg></a>
   </span>
   <span class="badge d-flex p-2 align-items-center ">
     <span class="text">tambah album</span>
     <a href="/album" class="text-primary-emphasis"><svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
   <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
 </svg></a>
   </span>
 </div>

<div class="box">
<input type="checkbox" id="check">
<!-- <div class="search-box">
 <input type="text" placeholder="Type here...">
 <label for="check" class="icon">
 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search-heart" viewBox="0 0 16 16">
<path d="M6.5 4.482c1.664-1.673 5.825 1.254 0 5.018-5.825-3.764-1.664-6.69 0-5.018"/>
<path d="M13 6.5a6.47 6.47 0 0 1-1.258 3.844q.06.044.115.098l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1-.1-.115h.002A6.5 6.5 0 1 1 13 6.5M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11"/>
</svg> -->
   <!-- <i class="fas fa-search"></i> -->
 </label>
</div>
</div>
 <nav class="navigation">
   <a href="/register"></a> 
   <a href="/home">Logout</a>    
 </nav>
</header>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <div class="back">
    </div>
    <div class = "container">
     <!-- ... (bagian HTML yang lain tetap sama) ... -->
<?php $__currentLoopData = $bebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container">
        <main class="grid">
            <article style="background-color: #E1F0DA !important;">
            <a href="/album<?php echo e($item->AlbumID); ?>"><img src="foto/44.png" width="150px" height="150px"></a> 
                <div class="konten">
                    <h2><?php echo e($item->NamaAlbum); ?></h2>
                    <p><?php echo e($item->Deskripsi); ?></p>
                    <p><?php echo e($item->TanggalDibuat); ?></p>
                    <!-- untuk hapus foto -->
                    <a href="/hapusdata/<?php echo e($item->AlbumID); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16" style="vertical-align: middle; margin-top: -16px; color: red;">
  <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
</svg></a>

                </div>
            </article>
        </main>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </body>
</html><?php /**PATH C:\Users\10543\galerywebsite\resources\views/kategori.blade.php ENDPATH**/ ?>