-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 22, 2024 at 07:16 AM
-- Server version: 8.0.30
-- PHP Version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `AlbumID` int NOT NULL,
  `NamaAlbum` varchar(225) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDibuat` date NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDibuat`, `UserID`) VALUES
(17, 'galau', 'kata kata galau', '2024-02-07', 8),
(27, 'meme', 'gtw ak', '2024-02-20', 10),
(28, 'flower', 'byutiful', '2024-02-20', 16),
(29, 'wlppr', '-', '2024-02-20', 16),
(30, 'random things', 'bebas apa aja', '2024-02-20', 16),
(31, 'random', 'cute human', '2024-02-20', 1),
(32, '-', 'apaja', '2024-02-21', 10),
(33, 'cute', 'apasaja', '2024-02-22', 17),
(35, 'pemandangan', 'view', '2024-02-22', 19);

-- --------------------------------------------------------

--
-- Table structure for table `foto`
--

CREATE TABLE `foto` (
  `FotoID` int NOT NULL,
  `JudulFoto` varchar(225) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFile` varchar(225) NOT NULL,
  `AlbumID` int NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `foto`
--

INSERT INTO `foto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFile`, `AlbumID`, `UserID`) VALUES
(5, 'lezat', 'enak bgt', '2024-02-06', 'public/penyimpanan/XV1Iil1okuQpvFKbrn7HPAOW8ND44EMqwxHtSJ5W.jpg', 16, 7),
(6, 'seken cois', 'queuutes', '2024-02-07', 'public/penyimpanan/S2PhEvgYg41lrJyuZD7DaHWB9OooZ4E86ghYeYdQ.jpg', 17, 8),
(8, 'pemandangan', 'view', '2024-02-07', 'public/penyimpanan/h63GvHieXBHTkHjF8b037gYF6iTIRi3EMWSjzlkY.jpg', 13, 1),
(9, 'hewan', 'kelinci', '2024-02-13', 'public/penyimpanan/yqnMJwd00PDokTKNRe6fSHgzPqv9ubu1ZGoPbmaG.jpg', 19, 1),
(10, 'kiki', 'friends', '2024-02-13', 'public/penyimpanan/hcjL5apPcJCi816SGyzAI7BcA17wHMeWdWfg2TLc.jpg', 20, 1),
(11, 'ponyo', 'cute ponyo', '2024-02-13', 'public/penyimpanan/9IIhLDZgvUtop64vTTxSIhGM2bNc2JEpsOFTf0KX.jpg', 20, 1),
(12, 'Jeno nct', 'Jeno icons', '2024-02-16', 'public/penyimpanan/PsjQwGGRfBQZtVhPHp17uasMHHmUZ16u8W8JOsOn.jpg', 21, 10),
(13, 'Mark school', '-', '2024-02-16', 'public/penyimpanan/VSAd9M4H8Kit770QBRYpxQfeRBviBj3MgXXu2pgu.jpg', 21, 10),
(15, 'cry', 'meme', '2024-02-16', 'public/penyimpanan/qXwF8PaJerqNJm8PmEFgrGVEy1qFUUyJ6kOa6VOA.jpg', 13, 1),
(21, 'lee dong wook', 'aktor', '2024-02-16', 'public/penyimpanan/EQMvcs5tiwiJV0mP6ppDyNqX1LVWj5d5VsrEgcgW.jpg', 21, 10),
(22, 'sho', 'ghibli vibs', '2024-02-16', 'public/penyimpanan/50jTTdDFd9GSkX0w8IOPzSIJQG7aWadAQ7soZMJk.jpg', 24, 10),
(23, 'jeno', 'jeno ganteng', '2024-02-20', 'public/penyimpanan/JyFGnrpro2ls8679Tq9LPzcYtr3h5xTThyPEeuMc.jpg', 25, 10),
(24, 'senku', 'dr.stone', '2024-02-20', 'public/penyimpanan/oXVyvyKLcbtUTfK2fRD9S4spBuBz5FwydD9twOE0.jpg', 26, 10),
(26, 'sho', 'ghibli', '2024-02-20', 'public/penyimpanan/jJWp70gqEGuKzUuXw0tMAhK3EwL50HNTf2tM8Bw5.jpg', 26, 10),
(27, 'good things (?)', 'sunsettttttttttt', '2024-02-20', 'public/penyimpanan/5I8yaGWiLZ7r9H8dd7Pp6aMF8funI8IlPikwaIkO.jpg', 14, 1),
(28, 'eat', 'deliciusssssssssssssssssssss', '2024-02-20', 'public/penyimpanan/WUGIdR48sgRI5Q6RhxEexeXIJnA8XhMcK0MKVYyV.jpg', 14, 1),
(29, '-', '--', '2024-02-20', 'public/penyimpanan/I7tqPfyVp1hy51PNaSdAImpZbXmX1txDOM3AChYr.jpg', 20, 1),
(30, 'pretty flower', '?', '2024-02-20', 'public/penyimpanan/io0ESbZk5AyOLueNgwI26fpRdhF3YsWkAdqniXY7.jpg', 28, 16),
(31, 'wallpaper desktop', 'inspirasi wallpaper', '2024-02-20', 'public/penyimpanan/1UAN1kUFt7x1fhCSpA5c5LsLD6W6aYhiFAgHhlR6.jpg', 29, 16),
(32, 'galau bos', 'apaya', '2024-02-20', 'public/penyimpanan/NrndWoqEK6Posn8VpGYnSal8ckQ07fbDOXUaU4J7.jpg', 29, 16),
(33, 'apayaaa', 'gtw', '2024-02-20', 'public/penyimpanan/WwXTD8d812p5aMNOyjFySnPKOHdpxmK08CExFpQR.jpg', 29, 16),
(34, 'midnight', '?', '2024-02-20', 'public/penyimpanan/0RVoZxn8qpEgGoCIKtyu2HX673P5EHkt1MYKI1Vz.jpg', 29, 16),
(35, '>_<', 'AAAAAAAAAA', '2024-02-20', 'public/penyimpanan/q4LOri7IDFV4S9VbOx8nKqDaAasxMBxs7Smb486l.jpg', 28, 16),
(36, 'O.O', 'cantik', '2024-02-20', 'public/penyimpanan/NjcjXYmAWstxzo4XUkHfaq5AbfRNm9E60tPoUUvY.jpg', 28, 16),
(37, 'kipop', 'yelooww', '2024-02-20', 'public/penyimpanan/Pl5mysblmDNR6GWxww20mYF4EUf1mevxDJ7bah0G.jpg', 30, 16),
(38, 'yuyujkb', 'bjhjhjko', '2024-02-20', 'public/penyimpanan/6wnYKjPrrNZui6eb7wTc5nXwBiUCV8RlLvdZ8KKx.jpg', 30, 16),
(39, 'cat', 'two cat', '2024-02-20', 'public/penyimpanan/iwXpAIjR9qHQGjpe7A1xctzjLkzH27IYtUVOSGoq.jpg', 29, 16),
(41, 'busrek', 'seken cois', '2024-02-21', 'public/penyimpanan/KXW5PMZBESeHp7ALbS03vWE3JXcrgmzQk1QY7PXj.jpg', 32, 10),
(43, 'apasaja', 'kk', '2024-02-22', 'public/penyimpanan/vmGvzPg1GwnUMgiLabruyRaf7cjoj04KHAXATBvY.jpg', 31, 1),
(45, 'sunset', '.', '2024-02-22', 'public/penyimpanan/Va4FFCfSoelWZksLJSkMpAt2I8vu8bBNiaCdITQs.jpg', 35, 19);

-- --------------------------------------------------------

--
-- Table structure for table `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(1, 4, 1, 'nice', '2024-02-12'),
(3, 4, 1, 'koksksdk', '2024-02-12'),
(4, 5, 1, 'hallo', '2024-02-12'),
(5, 4, 10, 'cute girl', '2024-02-13'),
(6, 4, 10, 'hi', '2024-02-13'),
(8, 17, 1, 'KOK LUCU BGTTTT', '2024-02-16'),
(9, 17, 10, 'cantik nan gemoy', '2024-02-16'),
(10, 17, 11, 'keritingnya gemassss', '2024-02-16'),
(11, 17, 11, 'CANTIKKUUUUU', '2024-02-16'),
(12, 29, 16, 'cute', '2024-02-20'),
(13, 25, 16, 'hahahahah', '2024-02-20'),
(15, 27, 17, 'sngt bagus aku suka!', '2024-02-22'),
(16, 43, 1, 'AHAHAHAHA NGAKAK BGT', '2024-02-22'),
(17, 31, 10, 'so cute !', '2024-02-22'),
(18, 32, 19, 'kkkk', '2024-02-22'),
(19, 45, 19, 'bgus', '2024-02-22'),
(20, 45, 1, 'lucuuu', '2024-02-22'),
(21, 34, 1, 'midnight?', '2024-02-22');

-- --------------------------------------------------------

--
-- Table structure for table `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(18, 14, 1, '2024-02-20'),
(19, 29, 16, '2024-02-20'),
(20, 25, 16, '2024-02-20'),
(21, 35, 16, '2024-02-20'),
(22, 32, 16, '2024-02-20'),
(23, 27, 17, '2024-02-22'),
(24, 43, 1, '2024-02-22'),
(25, 31, 1, '2024-02-22'),
(26, 31, 10, '2024-02-22'),
(27, 32, 19, '2024-02-22'),
(28, 45, 19, '2024-02-22'),
(29, 45, 1, '2024-02-22'),
(31, 34, 1, '2024-02-22');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int NOT NULL,
  `Username` varchar(225) NOT NULL,
  `Password` varchar(225) NOT NULL,
  `Email` varchar(225) NOT NULL,
  `NamaLengkap` varchar(225) NOT NULL,
  `Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`) VALUES
(1, 'intan', '24', 'tan@gmail.com', 'tanjez', 'keban agung'),
(2, 'intan', '24', 'tan@gmail.com', 'tanjez', 'keban agung'),
(3, 'intan', '24', 'tan@gmail.com', 'tanjez', 'keban agung'),
(4, 'intan', '24', 'tan@gmail.com', 'tanjez', 'keban agung'),
(5, 'intan', '24', 'tan@gmail.com', 'tanjez', 'keban agung'),
(6, 'intan', '24', 'tan@gmail.com', 'tanjez', 'keban agung'),
(7, 'ais', '11', 'ais@gmail', 'aisyh', 'karang asam'),
(8, 'lee jeno', '22', 'jeno@gmail.com', 'lee jeno', 'korea'),
(9, 'dafiti', '2222', 'dagfit@gmail.com', 'daefit aaaaaahmadane', 'canada'),
(10, 'ais', '77', 'pais@gmail.com', 'ais nur sak', 'kaarag'),
(11, 'bila', '19', 'bilacuy@gmail.com', 'bila dan aftar forever', 'minahasa'),
(12, 'bila', '19', 'bilacuy@gmail.com', 'bila dan aftar forever', 'minahasa'),
(13, 'bila', '19', 'bilacuy@gmail.com', 'bila dan aftar forever', 'minahasa'),
(14, 'lidia', 'tiwi', 'tiwikwik@gmail.com', 'LYDIA IMUEYYYY', 'tegarejo'),
(15, 'lidia', 'tiwi', 'tiwikwik@gmail.com', 'LYDIA IMUEYYYY', 'tegarejo'),
(16, 'lydia', '00', 'lid@gmail.com', 'lydia ? UHUYY', 'oooo'),
(17, 'Raihanah', 'agoy', 'raihanahhana@gmail.com', 'Raihanah Jinan Ulya', 'tere'),
(18, 'intanzhr', '11', 'intntan@gmail.com', 'Intan Azzahra A.P', 'Korsel'),
(19, 'intanlydia', '23', 'intanlyd@gmail.com', 'intan zhraaa', 'talang jawa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`);

--
-- Indexes for table `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`FotoID`);

--
-- Indexes for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`);

--
-- Indexes for table `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `foto`
--
ALTER TABLE `foto`
  MODIFY `FotoID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
